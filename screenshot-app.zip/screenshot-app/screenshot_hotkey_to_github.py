import os
import tempfile
import logging
from datetime import datetime
import configparser
import threading # For non-blocking operations
import time

from PIL import ImageGrab
from github import Github
from github.GithubException import UnknownObjectException, GithubException
import keyboard # For global hotkeys

# --- Configuration ---
CONFIG_FILE = "config_github_hotkey.ini"
LOG_FILE = "screenshot_github_hotkey.log"

# Global variable to hold loaded config
GIT_CONFIG = None

# --- Logging Setup ---
# Ensure log file is writable in the script's directory or a specified path
log_formatter = logging.Formatter('%(asctime)s - %(levelname)s - [%(threadName)s] - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# File Handler
try:
    file_handler = logging.FileHandler(LOG_FILE)
    file_handler.setFormatter(log_formatter)
    logger.addHandler(file_handler)
except PermissionError:
    print(f"ERROR: Could not write to log file {LOG_FILE}. Check permissions.")
    # Fallback to console logging if file logging fails
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(log_formatter)
    logger.addHandler(console_handler)
    logger.warning("Logging to console due to file permission error.")


# Console Handler (optional, for seeing logs in terminal when not running with pythonw.exe)
console_handler = logging.StreamHandler()
console_handler.setFormatter(log_formatter)
logger.addHandler(console_handler)


def load_config():
    """Loads configuration from config_github_hotkey.ini"""
    global GIT_CONFIG
    config = configparser.ConfigParser()
    if not os.path.exists(CONFIG_FILE):
        logger.error(f"{CONFIG_FILE} not found. Please create it.")
        config['GitHub'] = {
            'token': 'YOUR_GITHUB_PERSONAL_ACCESS_TOKEN',
            'repo_name': 'your_username/your_repository_name',
            'branch': 'main',
            'folder_in_repo': 'screenshots'
        }
        config['Hotkeys'] = {
            'trigger_hotkey': 'ctrl+alt+s', # Example hotkey
            'exit_hotkey': 'ctrl+alt+q'    # Hotkey to gracefully exit the script
        }
        with open(CONFIG_FILE, 'w') as configfile:
            config.write(configfile)
        logger.info(f"Created a template {CONFIG_FILE}. Please edit it with your details.")
        return False # Indicate failure to load existing config

    config.read(CONFIG_FILE)
    GIT_CONFIG = config # Store loaded config globally
    logger.info(f"Configuration loaded from {CONFIG_FILE}")
    return True

def take_screenshot_and_upload():
    """The actual work: take screenshot and upload. Meant to be run in a thread."""
    if not GIT_CONFIG:
        logger.error("GitHub configuration not loaded. Aborting screenshot task.")
        return

    logger.info("Hotkey triggered! Attempting to take screenshot and upload...")

    # 1. Take Screenshot
    try:
        screenshot = ImageGrab.grab()
        temp_file = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
        local_image_path = temp_file.name
        screenshot.save(local_image_path)
        temp_file.close() # Close it so other operations can access it
        logger.info(f"Screenshot taken and saved to temporary file: {local_image_path}")
    except Exception as e:
        logger.error(f"Error taking screenshot: {e}")
        return

    # 2. Upload to GitHub
    github_token = GIT_CONFIG['GitHub']['token']
    repo_name = GIT_CONFIG['GitHub']['repo_name']
    branch = GIT_CONFIG['GitHub']['branch']
    folder_in_repo = GIT_CONFIG['GitHub'].get('folder_in_repo', '').strip('/')

    try:
        g = Github(github_token)
        repo = g.get_repo(repo_name)
    except GithubException as e:
        logger.error(f"Failed to connect to GitHub or get repo '{repo_name}': {e.status} {e.data}")
        if e.status == 401: logger.error("Authentication failed. Check GitHub token.")
        elif e.status == 404: logger.error(f"Repo '{repo_name}' not found.")
        if os.path.exists(local_image_path): os.remove(local_image_path) # Clean up
        return

    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    remote_filename = f"screenshot_{timestamp}.png"
    path_in_repo = f"{folder_in_repo}/{remote_filename}" if folder_in_repo else remote_filename
    commit_message = f"Add screenshot: {remote_filename}"

    try:
        with open(local_image_path, 'rb') as f_content:
            content_bytes = f_content.read()

        # Check if file exists is complex, easier to just try to create with unique names
        repo.create_file(
            path=path_in_repo,
            message=commit_message,
            content=content_bytes,
            branch=branch
        )
        logger.info(f"Successfully uploaded '{remote_filename}' to '{repo_name}/{path_in_repo}'")
        print(f"Screenshot {remote_filename} uploaded to GitHub!") # User feedback
    except UnknownObjectException:
        logger.error(f"Branch '{branch}' might not exist in repo '{repo_name}'.")
    except GithubException as e:
        logger.error(f"GitHub API error during file creation: {e.status} {e.data}")
        if e.status == 422: logger.error("File might already exist or path issue.")
    except Exception as e:
        logger.error(f"An unexpected error occurred during upload: {e}")
    finally:
        if os.path.exists(local_image_path):
            try:
                os.remove(local_image_path)
                logger.info(f"Temporary screenshot {local_image_path} deleted.")
            except Exception as e_del:
                logger.error(f"Error deleting temp file {local_image_path}: {e_del}")

def trigger_action():
    """Called by the hotkey. Starts the screenshot/upload in a new thread."""
    # Create and start a new thread for the task to avoid blocking the hotkey listener
    logger.debug("Trigger action called. Starting worker thread.")
    thread = threading.Thread(target=take_screenshot_and_upload, daemon=True)
    thread.name = f"ScreenshotWorker-{int(time.time())}"
    thread.start()

def main():
    logger.info("Starting Screenshot to GitHub Hotkey Listener...")

    if not load_config():
        logger.error("Failed to load configuration. Exiting.")
        print("Error: Configuration not loaded. Check logs and config_github_hotkey.ini. Exiting.")
        return

    # Check for placeholder values after attempting to load/create config
    if 'YOUR_GITHUB_PERSONAL_ACCESS_TOKEN' in GIT_CONFIG['GitHub']['token'] or \
       'your_username/your_repository_name' in GIT_CONFIG['GitHub']['repo_name']:
        warning_msg = "Default configuration values found. Please edit config_github_hotkey.ini with your actual details and restart."
        logger.warning(warning_msg)
        print(f"WARNING: {warning_msg}")
        # Optionally, could exit here if placeholders are critical
        # return

    trigger_hotkey_str = GIT_CONFIG['Hotkeys']['trigger_hotkey']
    exit_hotkey_str = GIT_CONFIG['Hotkeys']['exit_hotkey']

    try:
        keyboard.add_hotkey(trigger_hotkey_str, trigger_action)
        logger.info(f"Registered hotkey: '{trigger_hotkey_str}' to take screenshot.")
        print(f"Screenshot hotkey '{trigger_hotkey_str}' is active.")
    except Exception as e:
        logger.error(f"Failed to register trigger hotkey '{trigger_hotkey_str}': {e}")
        print(f"Error: Could not register hotkey '{trigger_hotkey_str}'. Another program might be using it, or permissions issue (especially on Linux/macOS).")
        return

    logger.info(f"Press '{exit_hotkey_str}' to quit the script.")
    print(f"Press '{exit_hotkey_str}' to quit.")

    # Keep the script running and wait for the exit hotkey
    keyboard.wait(exit_hotkey_str)

    logger.info(f"Exit hotkey '{exit_hotkey_str}' pressed. Shutting down...")
    print("Exit hotkey pressed. Shutting down...")
    # keyboard.unhook_all() # Good practice, though script exit will do this

if __name__ == "__main__":
    # Make sure CWD is script's directory for config/log files if running from elsewhere
    # os.chdir(os.path.dirname(os.path.abspath(__file__)))
    main()